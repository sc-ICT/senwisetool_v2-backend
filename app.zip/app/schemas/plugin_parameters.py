from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class PluginParametersBase(BaseModel):
    model_config = ConfigDict(extra="allow")


class PluginAcquisitionParameters(PluginParametersBase):
    availability: Literal["PUBLIC", "PRIVATE", "RESTRICTED"] = "PUBLIC"

    download_requires_approval: bool = False

    installation_requires_approval: bool = False

    approval_mode: Literal[
        "SIMPLE_REQUEST",
        "FORM",
        "DOCUMENT",
        "FORM_AND_DOCUMENT",
    ] = "SIMPLE_REQUEST"

    approval_form_key: str | None = None

    required_documents: list[str] = Field(
        default_factory=list,
    )

    instructions_title: str | None = None

    instructions_description: str | None = None

    require_terms_acceptance: bool = False

    terms_url: str | None = None

    @model_validator(mode="after")
    def validate_approval_configuration(
        self,
    ) -> "PluginAcquisitionParameters":

        approval_required = self.installation_requires_approval or self.download_requires_approval

        if self.approval_mode == "FORM" and approval_required and not self.approval_form_key:
            raise ValueError(
                "Un formulaire d'autorisation est obligatoire "
                "lorsque le mode d'autorisation est FORM.",
            )

        if (
            self.approval_mode == "FORM_AND_DOCUMENT"
            and approval_required
            and not self.approval_form_key
        ):
            raise ValueError(
                "Un formulaire d'autorisation est obligatoire "
                "lorsque le mode est FORM_AND_DOCUMENT.",
            )

        if (
            self.approval_mode
            in {
                "DOCUMENT",
                "FORM_AND_DOCUMENT",
            }
            and approval_required
            and not self.required_documents
        ):
            raise ValueError(
                "Au moins un document est requis " "pour un processus d'autorisation documentaire.",
            )

        if self.require_terms_acceptance and not self.terms_url:
            raise ValueError(
                "L'URL des conditions d'utilisation est obligatoire "
                "lorsque leur acceptation est requise.",
            )

        return self


class PluginInstallationParameters(PluginParametersBase):
    activation_required: bool = True

    activation_requires_approval: bool = False

    allow_auto_update: bool = True

    require_update_confirmation: bool = True

    allow_user_uninstall: bool = True

    uninstall_requires_approval: bool = False

    max_active_installations: int | None = Field(
        default=None,
        gt=0,
    )


class PluginPermissionParameters(PluginParametersBase):
    enabled: bool = True

    require_authentication: bool = True

    allow_admin_override: bool = True

    allow_custom_roles: bool = False

    default_access: Literal[
        "DENY",
        "READ",
        "USE",
        "MANAGE",
    ] = "USE"

    allow_data_export: bool = True

    allow_data_import: bool = True

    allow_bulk_operations: bool = True

    allow_audit_log_access: bool = False


class PluginResourceParameters(PluginParametersBase):
    allow_global_read: bool = True

    allow_global_create: bool = False

    allow_global_update: bool = False

    allow_global_delete: bool = False

    allow_global_import: bool = False

    allow_global_export: bool = True

    allow_user_create: bool = True

    allow_user_update: bool = True

    allow_user_delete: bool = True

    allow_user_import: bool = True

    allow_user_export: bool = True

    allow_bulk_operations: bool = True

    require_delete_confirmation: bool = True

    allow_offline_editing: bool = True

    allow_schema_override: bool = True


class PluginProgramParameters(PluginParametersBase):
    enabled: bool = True

    allow_user_join: bool = True

    join_requires_approval: bool = False

    allow_user_leave: bool = True

    allow_user_create: bool = False

    allow_user_manage: bool = False

    allow_parallel_programs: bool = True

    allow_multiple_programs_per_user: bool = True

    allow_manual_start: bool = True

    allow_automatic_start: bool = True

    allow_recurring_schedule: bool = True


class PluginProjectParameters(PluginParametersBase):
    enabled: bool = True

    allow_user_create: bool = True

    creation_requires_approval: bool = False

    allow_user_customize: bool = True

    allow_resource_override: bool = True

    allow_form_override: bool = False

    allow_rules_override: bool = False

    allow_multiple_active_projects: bool = True

    allow_self_assignment: bool = False

    allow_supervisor_assignment: bool = True

    allow_project_archive: bool = True

    allow_project_delete: bool = False

    allow_offline_execution: bool = True


class PluginCollectionParameters(PluginParametersBase):
    enabled: bool = True

    allow_drafts: bool = True

    auto_save_drafts: bool = True

    auto_save_interval_seconds: int = Field(
        default=30,
        ge=5,
        le=3600,
    )

    allow_partial_submission: bool = False

    require_validation_before_submission: bool = True

    require_submission_confirmation: bool = True

    allow_edit_after_submission: bool = False

    correction_requires_approval: bool = True

    allow_duplicate_submission: bool = False


class PluginMobileParameters(PluginParametersBase):
    enabled: bool = True

    offline_enabled: bool = True

    offline_allow_data_entry: bool = True

    offline_allow_data_edit: bool = True

    offline_allow_data_delete: bool = False

    max_offline_days: int | None = Field(
        default=30,
        gt=0,
    )

    automatic_sync: bool = True

    sync_wifi_only: bool = False

    sync_interval_seconds: int = Field(
        default=300,
        ge=30,
        le=86400,
    )

    retry_sync_on_failure: bool = True

    location_enabled: bool = True

    location_required_for_collection: bool = False

    location_required_for_submission: bool = False

    camera_enabled: bool = True

    file_upload_enabled: bool = True

    max_file_size_mb: int = Field(
        default=20,
        gt=0,
        le=1024,
    )

    allowed_file_extensions: list[str] = Field(
        default_factory=lambda: [
            "pdf",
            "jpg",
            "jpeg",
            "png",
        ],
    )

    notifications_enabled: bool = True


class PluginSecurityParameters(PluginParametersBase):
    session_max_idle_minutes: int = Field(
        default=60,
        gt=0,
    )

    encrypt_local_storage: bool = True

    encrypt_sensitive_fields: bool = True

    audit_enabled: bool = True

    audit_track_reads: bool = False

    audit_track_creates: bool = True

    audit_track_updates: bool = True

    audit_track_deletes: bool = True

    audit_track_exports: bool = True

    require_secure_device: bool = False

    block_rooted_or_modified_device: bool = False


class PluginPrivacyParameters(PluginParametersBase):
    allow_data_export: bool = True

    allow_data_deletion: bool = True

    retention_enabled: bool = False

    retention_days: int | None = Field(
        default=None,
        gt=0,
    )

    anonymize_after_retention: bool = False

    require_delete_confirmation: bool = True

    @model_validator(mode="after")
    def validate_retention(
        self,
    ) -> "PluginPrivacyParameters":

        if self.retention_enabled and self.retention_days is None:
            raise ValueError(
                "Le nombre de jours de conservation est obligatoire "
                "lorsque la conservation automatique est activée.",
            )

        return self


class PluginNotificationParameters(PluginParametersBase):
    enabled: bool = True

    notify_on_approval_request: bool = True

    notify_on_approval_decision: bool = True

    notify_on_sync_failure: bool = True

    notify_on_project_assignment: bool = True

    notify_on_submission: bool = True

    allow_push: bool = True

    allow_email: bool = True


class PluginLocalizationParameters(PluginParametersBase):
    default_language: str = "fr"

    supported_languages: list[str] = Field(
        default_factory=lambda: ["fr"],
    )

    timezone: str = "UTC"

    date_format: str = "DD/MM/YYYY"

    decimal_separator: Literal[".", ","] = ","


class PluginSupportParameters(PluginParametersBase):
    support_email: str | None = None

    support_url: str | None = None

    documentation_url: str | None = None

    report_issue_url: str | None = None


class PluginLegalParameters(PluginParametersBase):
    terms_url: str | None = None

    privacy_policy_url: str | None = None

    legal_notice_url: str | None = None

    license_name: str | None = None

    require_terms_acceptance_on_installation: bool = False


class PluginAdvancedParameters(PluginParametersBase):
    allow_experimental_features: bool = False

    debug_mode: bool = False

    expose_technical_errors: bool = False

    custom: dict[str, Any] = Field(
        default_factory=dict,
    )


class PluginParameters(PluginParametersBase):
    schema_version: int = Field(
        default=1,
        ge=1,
    )

    acquisition: PluginAcquisitionParameters = Field(
        default_factory=PluginAcquisitionParameters,
    )

    installation: PluginInstallationParameters = Field(
        default_factory=PluginInstallationParameters,
    )

    permissions: PluginPermissionParameters = Field(
        default_factory=PluginPermissionParameters,
    )

    resources: PluginResourceParameters = Field(
        default_factory=PluginResourceParameters,
    )

    programs: PluginProgramParameters = Field(
        default_factory=PluginProgramParameters,
    )

    projects: PluginProjectParameters = Field(
        default_factory=PluginProjectParameters,
    )

    collection: PluginCollectionParameters = Field(
        default_factory=PluginCollectionParameters,
    )

    mobile: PluginMobileParameters = Field(
        default_factory=PluginMobileParameters,
    )

    security: PluginSecurityParameters = Field(
        default_factory=PluginSecurityParameters,
    )

    privacy: PluginPrivacyParameters = Field(
        default_factory=PluginPrivacyParameters,
    )

    notifications: PluginNotificationParameters = Field(
        default_factory=PluginNotificationParameters,
    )

    localization: PluginLocalizationParameters = Field(
        default_factory=PluginLocalizationParameters,
    )

    support: PluginSupportParameters = Field(
        default_factory=PluginSupportParameters,
    )

    legal: PluginLegalParameters = Field(
        default_factory=PluginLegalParameters,
    )

    advanced: PluginAdvancedParameters = Field(
        default_factory=PluginAdvancedParameters,
    )
